# P09 reviewer-risk repair: scope fixed before execution

Date: 2026-09-09. User requested repair of three reviewer risks.

## Question and evidence role

Make the saved-record scheduling comparison independently executable, quantify
overlap and within-record parameter dependence, and compare realized resources
per replay. This is retrospective diagnostic analysis of already exposed records,
not a new independent test, physical experiment, or optimization of the manuscript
method. No new winning parameter will replace the frozen S0.

## Inputs and identity

Project context: DDET-MTD-q1-case39, q1_case39_expansion,
HEAD 4a4cfbec29abb7392882cf454998f86a81dd055d. Existing dirty files preserved.
Read-only P01/P02 records live under
D:/DDET_MTD_Pro交接/2026-09-05_TWO_TRACK_START/P_PUBLICATION.
P01 SHA-256: d772e5b13681e9e09ca3633da1f248f3a34a29230335cdf42099199e43dfd41d.
P02 SHA-256: cb6ddbb9ddcbc2e943ee4c33dcd6f2cd5547076a7040f43625934b9ea826d7d0.
Read-only implementation and historical ATC/planner references come from the
P05C/P08 directories in /home/pang/projects/DDET-MTD-q1-case39-p-eswa.
The assembly receipt records resolved paths, sizes, mtimes and hashes.

## Bounded execution

- Reproduce 8 saved 540-step records x 2 budgets x 5 existing methods = 80 traces.
- No re-estimation of predictions, labels, outcomes, or service durations.
- One-at-a-time S0 sensitivity: multiply each of v_weight, clean_penalty,
  busy_penalty, admission_score_threshold by 0.8 or 1.2, all 8 records and both
  budgets (128 traces). Also vary the nonzero B1 age_bonus by those factors
  (16 traces). B2 age_bonus remains zero; no meaningless duplicate zero variants.
- Total at most 224 saved-record traces, 120960 timeline steps, and 17280 planner
  MILP calls (actual calls recorded). No second run to obtain a preferred outcome.
- All perturbations, directions and failures are retained. This local +/-20%
  diagnostic is not joint/global robustness, parameter selection, or fresh testing.
- Weighted/count coverage, clean starts, total starts, realized busy steps, recorded
  cost, waiting and overlap of selected IDs are reported. Compare resources per
  record, not just equal aggregate means. No oracle duration enters policy decisions.
- No p-values treating overlapping replays as independent replicates.

## Isolation and limits

All new files stay in this new directory. Bundled Windows Python, one CPU thread,
no GPU, no production imports, no PF/OPF/SE/recovery/MTD/attack generation,
no R-line reads/writes, no shared-environment modification, no Git changes/push.
No old experiment rerun beyond the explicitly scoped portable scheduling replays.
Originals are not moved, deleted or overwritten. Publication of additional raw
records/code is a separate external action; do not imply it has happened.

Independent generalization remains an open research requirement unless genuinely
new, source-separated evidence is obtained. Deduplicating source IDs does not turn
the existing transformed replay jobs into independent events.
